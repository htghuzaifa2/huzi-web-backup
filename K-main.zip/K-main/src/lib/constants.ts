
export const APP_NAME = 'kimi.pk';
export const WHATSAPP_PHONE_NUMBER = '923329105111'; // Replace with a valid WhatsApp number
export const WHATSAPP_MESSAGE_HEADER = `Hello ${APP_NAME}, I'd like to place an order for the following items:`;

// A lightweight, base64-encoded blurry placeholder for images
export const BLUR_DATA_URL = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mN8XA8AAksBZG7lpHEAAAAASUVORK5CYII=';
