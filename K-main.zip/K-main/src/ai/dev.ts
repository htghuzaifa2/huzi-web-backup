import { config } from 'dotenv';
config();

import '@/ai/flows/related-product-recommendations.ts';
import '@/ai/flows/hashtag-generator.ts';
